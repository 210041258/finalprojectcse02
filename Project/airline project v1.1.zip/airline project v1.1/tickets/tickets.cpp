#include "tickets.h"
#include<fstream>
#define address_tickets "tickets.txt"
using namespace std;
tickets::tickets(int _id,string _from,string _where,string _date_go,string _date_ret,int _price,int _t_visa_req,int _t_cov_req)
{
    id=_id;
    from=_from;
    where=_where;
    date_go=_date_go;
    date_ret=_date_ret;
    price=_price;
    t_visa_req=_t_visa_req;
    t_cov_req=_t_visa_req;
}

tickets::~tickets()
{
    //dtor
}



int tickets::give_access_id()
{
    return tickets::id;
}
string tickets::give_access_from()
{
    return tickets::from;
}
string tickets::give_access_where()
{
    return tickets::where;
}
string tickets::give_access_date_go()
{
    return tickets::date_go;
}
string tickets::give_access_date_ret()
{
    return tickets::date_ret;
}
int tickets::give_access_price()
{
    return tickets::price;
}
int tickets::give_access_t_visa_req()
{
    return tickets::t_visa_req;
}
int tickets::give_access_t_cov_req()
{
    return tickets::t_cov_req;
}

void tickets::edit_access_id(int _id)
{
    id=_id;
}
void tickets::edit_access_form(string from_)
{
    from=from_;
}
void tickets::edit_access_where(string where_)
{
    where=where_;
}
void tickets::edit_access_date_go(string go_)
{
    date_go=go_;
}
void tickets::edit_access_date_ret(string return_)
{
    date_ret=return_;
}
void tickets::edit_access_price(int price_)
{
    price=price_;
}
void tickets::edit_access_t_visa_req(int visa_)
{
    t_visa_req=visa_;
}
void tickets::edit_access_t_cov_req(int cov_)
{
    t_cov_req=cov_;
}
int save_ticket_direct()
{
    ofstream finput(address_tickets,ios::app);
    finput << tickets::give_access_id << tickets::give_access_from;
    finput << tickets::give_access_where << tickets::give_access_date_go;
    finput << tickets::give_access_date_ret << tickets::give_access_price;
    finput << tickets::give_access_t_visa_req << tickets::give_access_t_cov_req;
    return 1;
}

int search_id(int id_)
{
    ifstream fileoutput(address_tickets);
    while(!(fileoutput.eof()))
    {
    }
}

